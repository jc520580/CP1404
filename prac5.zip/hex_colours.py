C_Name_List=dict(aliceblue="#f0f8ff",antiquewhite="#f0f8ff",aquamarine="#f0f8ff")

C_Name=input("enter:")
while C_Name!="":
    if C_Name.lower() in b:
        print(C_Name,"is",C_Name_List[C_Name.lower()])
    else:
        print("invalid")