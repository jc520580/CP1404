text="this is a collection of words of nice words this is a fun thing it is"
split=text.split(' ')
dic=dict(this=0,a=0,collection=0)
count_this=0
for i in split:
    if i=="this":
        count_this=count_this+1

dic['this']=count_this

print("this:",dic['this'])