class guitar:
    def __init__(self,name,year,cost):
        self.name=name
        self.year=year
        self.cost=cost
        self.age = 2018 - self.year

    def is_vintage(self):
        if self.age>=50:
            return True
        else:
            return False


    def __str__(self):
        return "{}({}):$ {}".format(self.name,self.year,self.cost)

