
class ProgrammingLanguage:

    def __init__(self,L_name,L_type,is_dynamic,year):
        self.L_name=L_name
        self.L_type=L_type
        self.is_dynamic=is_dynamic
        self.year=year

    def __str__(self):

        return "{},{} Typing,{},First appear in {}".format(self.L_name,self.L_type,self.is_dynamic,self.year)





def main():
    print("12")
    ruby = ProgrammingLanguage("Ruby", "Dynamic", True, 1995)
    python = ProgrammingLanguage("Python", "Dynamic", True, 1991)
    visual_basic = ProgrammingLanguage("Visual Basic", "Static",False, 1991)
    print(ruby)
    print(python)
    print(visual_basic)
    list1=[ruby,python,visual_basic]
    for i in list1:
        if i.is_dynamic:
            print(i.L_name)


main()